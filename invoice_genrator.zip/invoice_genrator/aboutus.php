<?php require_once 'includes/header.php'; ?>
  <style type="text/css">
    body{
  margin: 0;
  padding: 0;
}
body{
background-image: url('images/bg.jpg'); background-repeat: no-repeat; background-size: cover;
}

.about{
  width: 100%;
  height: 300px;
  background-color: #262626;
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  display: flex;
  
  justify-content: center;
  flex-wrap: wrap;
}
.text{
  font-size:100px;
  color: #fff;
  font-family: sans-serif;  
  text-shadow: 0px 15px 12px #000;
}
.line{
  width: 200px;
  height: 8px;
  background-color: #d9d9d9;
  display: block;
  position: relative;
  border-radius: 5px;
  
  box-shadow: 0px 15px 12px 0px #000;
}
.content{
  width: 100%;
  height: auto;
  background-color: #d9d9d9;
  font-size:23px;
  font-family: autowide;
  color: #333;
  line-height: 30px;
  text-align: center;
}
.b{
  font-size: 50px;
  color: #000;
  font-weight: 500px;

}
footer{
  width: 100%;
  height: auto;
  background-color: #333;
  color: #d9d9d9;
  font-size: 23px;
  text-align: center;
  line-height: 50px;

}

  </style>
  <div class="container" style="width: 90%;"> 
    <div class="about"> 	
      <div class="text">
        <h1 style="font-size: 40px; margin-top: 100px;"><b><u>About Project</u></b></h1>
        
      </div>
     </div>
     <div class="content"><br>
     <p><b>"INVOICE GENRATOR"</b><br>
       <br>  Fully functional inventory management software that can help you manage all your invoices and customers,you can now create and manage invoices in your browser on any devices.It is user-friendly and a very secure software that the company can use to store all their information about the clients and manages their accoount. It enables to group the product with their
         category as well as their respective brand and if required the all the details/report of previously generated bills can be checked easily.<br>


        <br><b>FEATURES</b></br>
        Invoice generation and easy to print download invoice in PDF format
        <br>
        -Lightweight and easy to use
        <br>
        -Order management and product management can be done with ease
        <br>
        -Report management
        <br>
        -User wise sell report.
        <br>
        <br><b>USECASE</b></br>
        Creating a invoice for all products

        The information regarding the clients are stored in databse and can be used which invoice creation.

        The complete product managemnt is provided along with their category

        The product and be sorted with their brand as well as category

        Registered admin can access the previous bill at their convinence with reports</p>

     </div>
     </div>
     <footer>Copyright &copy;.... 2021</footer>
         